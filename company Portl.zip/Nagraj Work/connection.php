<?php
$hostname="localhost:3308";
$username="root";
$password="";
$databasename="loginsystem";

$conn=mysqli_connect($hostname,$username,$password,$databasename);
?>