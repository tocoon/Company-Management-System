<?php 
session_start();
require 'navbar.php';
echo "<br>";
require 'connection.php';

if($_SERVER['REQUEST_METHOD']=="POST")
{
    $userid=$_POST["userid"];
    $password=$_POST["password"];
    $cpassword=$_POST["cpassword"];

    if(isset($_POST['registration'])) 
    {
        header("location:registrationpage.php");
    }
    
    if($password!=$cpassword)
    {
        echo '<div class="container"><div 
            class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>Login Failed! </strong> Because Password is not Matched.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div></div>';
    }
    else
    {
        $select="SELECT * FROM REGISTRATIONTABLE WHERE USERID='$userid' AND PASSWORD='$password'";
        $result=mysqli_query($conn,$select);
        $data=mysqli_fetch_assoc($result);
        
            $rows=mysqli_num_rows($result);
            if($rows==1)
            {
                echo '<div class="container"><div
                    class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong>Congratulations !</strong> Login Successfull .
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div></div>';
                    
                    $_SESSION["userid"]=$userid;
                    $_SESSION["password"]=$password;
                    
                    if(isset($_POST['login'])) 
                        header("location:companycategory.php");
            }

            else
            {
                echo '<div class="container"><div
                    class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Oops!</strong> Login Failed Because No Account Found.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div></div>';
            }
    }
}
?>

<html>
<body>
<br><br>
<div class="container">
        <form method="POST">

             <div class="mb-3">
                <label for="uid" class="form-label"><b>Enter Your User-Id :- </b></label>
                <input type="text" id="uid" class ="form-control" name="userid" size=30 placeholder="Enter Your User-Id">
            </div>

            <div class="mb-3">  
                <label for="pass" class="form-label"><b>Enter Your Password :- </b></label>
                <input type="password" class ="form-control" id="pass" name="password" size=30 placeholder="Enter Your Password">    
            </div>

            <div class="mb-3">  
                <label for="pass1" class="form-label"><b>Enter Your Password Again:- </b></label>
                <input type="password" class ="form-control" id="pass1" name="cpassword" size=30 placeholder="Enter Your Password Again">    
            </div>

 
            <div class="d-grid gap-2">
                <input class="btn btn-primary type="button" type="submit" name="login" value="Login"><br><br>
                <input class="btn btn-primary type="button" type="reset" value="Reset"><br><br>   
                <input class="btn btn-primary type="button" type="submit" name="registration" value="New Member Click here for Registration"><br><br>       
            </div>

        </form>
    </div><br>

</body>
</html>

<?php require 'footer.php'?><br><br>