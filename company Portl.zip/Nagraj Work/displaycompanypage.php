<?php 
session_start();
require 'navbar.php';
echo "<br>";
require 'connection.php';
?>

<html>
<body>
<h2 align="center">ALL COMPANY DETAILS</h2><br>
        <table border="4px" align="center">
            <tr>
                <th>Company Name</th>
                <th>Company Website</th>
                <th>Company Number</th>
                <th>Company Address</th>
                <th>City</th>
                <th>State</th>
                <th>Country</th>
            </tr>
            <?php
                $select="SELECT * from addcompany";
                $result=mysqli_query($conn,$select);
                while($rows=mysqli_fetch_assoc($result))
                {
             ?>
            <tr>
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['website'];?></td>
                <td><?php echo $rows['number'];?></td>
                <td><?php echo $rows['address'];?></td>
                <td><?php echo $rows['city'];?></td>
                <td><?php echo $rows['state'];?></td>
                <td><?php echo $rows['country'];?></td>
            </tr>
            <?php
                }
             ?>
        </table>
<br><br>
</body>
</html>
<?php require 'footer.php'?><br><br>