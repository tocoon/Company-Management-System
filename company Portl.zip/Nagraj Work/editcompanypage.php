<?php 
session_start();
require 'navbar.php';
echo "<br>";
require 'connection.php';
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $name=$_POST["name"];
    $website=$_POST["website"];
    $number=$_POST["number"];
    $address=$_POST["address"];
    $city=$_POST["city"];
    $state=$_POST["state"];
    $country=$_POST["country"];

    $insert="UPDATE addcompany set name='$name',website='$website',number='$number',address='$address',city='$city',state='$state',country='$country' where name='$name'";
    $result=mysqli_query($conn,$insert);
    if($result)
    {
        echo '<div class="container"><div
            class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Congratulations!</strong> Company Successfully Edited.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div></div>';
    }

    else
    {
        echo '<div class="container"><div
            class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Oops!</strong> Company Edited Failed Because '.mysqli_error($conn).' Found.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div></div>';
    }
}
?>

<html>
<head>
    <title></title>
</head>
<body>
<h2 align="center">EDIT COMPANY DETAILS</h2>
    <form method="post" action="editcompanypage.php">
    <table align="center" border="5" cellspacing="8" cellpadding="8">
        <tr>
            <td>COMPANY NAME</td>
            <td><input type="text" name="name"></td>
        </tr>
        <tr>
            <td>COMPANY WEBSITE</td>
            <td><input type="text" name="website"></td>
        </tr>
 <tr>
            <td>COMPANY PHONE NUMBER</td>
            <td><input type="number" name="number"></td>
        </tr>
      
        <tr>
            <td>COMPANY ADDRESS</td>
            <td><textarea rows="4" cols="20" name="address"></textarea></td>
        </tr>
        <tr>
 <tr>
            <td>COMPANY CITY</td>
            <td><textarea rows="2" cols="20" name="city"></textarea></td>
        </tr>
      <tr>
            <td>COMPANY STATE</td>
            <td><textarea rows="2" cols="20" name="state"></textarea></td>
        </tr>
 <tr>
            <td>COMPANY COUNTRY</td>
            <td><textarea rows="2" cols="20" name="country"></textarea></td>
        </tr>
                      
          
           </td>
           
           <td colspan="3" align="center">
                <input type="submit" name="submit" value="EDIT">
            </td>
        </tr>
</table>
</form>
</body>
</html>
<?php require 'footer.php'?><br><br>