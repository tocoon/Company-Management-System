<?php 
session_start();
session_unset();
session_destroy();

echo '<div class="container"><div
        class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Oops!</strong> Logout Successfull.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div></div>';

header("location:homepage.php");
?>