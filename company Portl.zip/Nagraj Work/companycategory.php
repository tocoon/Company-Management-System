<?php 
session_start();
require 'navbar.php';
echo "<br>";
require 'connection.php';

if($_SERVER['REQUEST_METHOD']=="POST")
{
    if(isset($_POST['add'])) 
    {
        header("location:addcompanypage.php");
    }

    if(isset($_POST['edit'])) 
    {
        header("location:editcompanypage.php");
    }

    if(isset($_POST['delete'])) 
    {
        header("location:deletecompanypage.php");
    }

    if(isset($_POST['display'])) 
    {
        header("location:displaycompanypage.php");
    }
}
?>

<html>
<body>
<br><br>
<div class="container">
<form method="post">
    <div class="d-grid gap-2">
            <input class="btn btn-primary type="button" name="add" type="submit" value="Add Company"><br><br>
            <input class="btn btn-primary type="button" name="edit" type="submit" value="Edit Company"><br><br>    
            <input class="btn btn-primary type="button" name="delete" type="submit" value="Delete Company"><br><br>    
            <input class="btn btn-primary type="button" name="display" type="submit" value="Display Company"><br><br>       
    </div>
</form>
</div><br>
</body>
</html>
<?php require 'footer.php'?><br><br>