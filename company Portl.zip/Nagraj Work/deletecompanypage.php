<?php 
session_start();
require 'navbar.php';
echo "<br>";
require 'connection.php';
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $name=$_POST["name"];
    $insert="delete from addcompany where name='$name'";
    $result=mysqli_query($conn,$insert);
    if($result)
    {
        echo '<div class="container"><div
            class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Congratulations!</strong> Company Successfully Deleted.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div></div>';
    }

    else
    {
        echo '<div class="container"><div
            class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Oops!</strong> Company Deletion Failed Because '.mysqli_error($conn).' Found.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div></div>';
    }
}
?>

<html>
<head>
    <title></title>
</head>
<body>
<h2 align="center">DELETE COMPANY DETAILS</h2>
    <form method="post" action="deletecompanypage.php">
    <table align="center" border="5" cellspacing="8" cellpadding="8">
        <tr>
            <td>TYPE COMPANY NAME</td>
            <td><input type="text" name="name"></td>
        </tr>
           
           <td colspan="3" align="center">
                <input type="submit" name="submit" value="DELETE">
            </td>
</table>
</form>
</body>
</html>
<?php require 'footer.php'?><br><br>