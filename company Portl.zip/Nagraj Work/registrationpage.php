<?php

session_start();
session_unset();
session_destroy();

require 'navbar.php';
require 'connection.php';
echo "<br>";

if($_SERVER['REQUEST_METHOD']=="POST")
{
    $userid=$_POST["userid"];
    $password=$_POST["password"];
    $name=$_POST["fullname"];

    $insert="INSERT INTO REGISTRATIONTABLE VALUES('$userid','$password','$name')";
    $result=mysqli_query($conn,$insert);
    if($result)
    {
        echo '<div class="container"><div
            class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Congratulations!</strong> Registration Successfull . <a href="loginpage.php"><b>Click Here To Login</b></a>.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div></div>';
    }

    else
    {
        echo '<div class="container"><div
            class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>Oops!</strong> Registration Failed Because '.mysqli_error($conn).' Found.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div></div>';
    }
}
?>

<html>
<body>
<br><br>
<div class="container">
        <form action="registrationpage.php" method="POST">

             <div class="mb-3">
                <label for="uid" class="form-label"><b>Enter Your User-Id :- </b></label>
                <input type="text" id="uid" class ="form-control" name="userid" size=30 placeholder="Enter Your User-Id">
            </div>

            <div class="mb-3">  
                <label for="pass" class="form-label"><b>Enter Your Password :- </b></label>
                <input type="password" class ="form-control" id="pass" name="password" size=30 placeholder="Enter Your Password">    
            </div>

            <div class="mb-3"> 
                <label for="fullname" class="form-label"><b>Enter Your Full Name :- </b></label>
                <input type="text" class ="form-control" id="fullname" name="fullname" size=30 placeholder="Enter Your Full Name">
            </div>    

            <div class="d-grid gap-2">
                <input class="btn btn-primary type="button" type="submit" value="Registration"><br><br>
                <input class="btn btn-primary type="button" type="reset" value="Reset"><br><br>       
            </div>

        </form>
    </div><br>

</body>
</html>

<?php require 'footer.php'?><br><br>