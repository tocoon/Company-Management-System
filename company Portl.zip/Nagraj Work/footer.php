<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
 <!-- =================================================================================================================== -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
 <div class="container">
    <div class="alert alert-success" role="alert">
        <h4 class="alert-heading">Thanks,for Visiting our site!!</h4>
        <p>© 2022 MH Sub I, LLC., all rights reserved | 
        <nav style="--bs-breadcrumb-divider: ' | ';" aria-label="breadcrumb">
            <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Privacy Policy</a></li>
            <li class="breadcrumb-item"><a href="#">Cookies</a></li>
            <li class="breadcrumb-item"><a href="#">Terms of Service</a></li>
            <li class="breadcrumb-item"><a href="#">Terms of Use</a></li>
            <li class="breadcrumb-item"><a href="#">Do Not Sell My Personal Information</a></li>
            </ol>
        </nav>
        </p>
        <hr>
    </div>
</div> 

</body>
</html>